# ezLMM: A Python Script for Linear Mixed Model using rpy2

### What to download
[lmm_acc.py](https://github.com/Paradeluxe/pyLMM/blob/master/lmm_acc.py) and [lmm_rt.py](https://github.com/Paradeluxe/pyLMM/blob/master/lmm_rt.py) are all you want.
